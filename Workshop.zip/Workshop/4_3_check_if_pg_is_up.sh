#!/bin/bash

kubectl get pods
