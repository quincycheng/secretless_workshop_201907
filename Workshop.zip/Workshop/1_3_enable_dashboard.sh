#!/bin/bash
minikube addons enable dashboard

echo 'Execute "minikube dashboard" in a separated terminal to open the kubernetes dashboard'
