#!/bin/bash

sudo yum install -y words
