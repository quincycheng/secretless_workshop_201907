#!/bin/bash

cat ./test-app/test-app-conjur.yml
