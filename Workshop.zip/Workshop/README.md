# conjur-oss-katacoda

This is the repo for demostrating kubernetes authenication using Conjur OSS.

The scripts are folked & modified from  amacias-cyberark/-conjur-oss-gke

Credits to amacias-cyberark
