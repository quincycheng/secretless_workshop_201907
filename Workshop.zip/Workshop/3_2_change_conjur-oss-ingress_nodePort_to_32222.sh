#!/bin/bash

kubectl edit service --namespace conjur
