CREATE USER test_app PASSWORD '5b3e5f75cb3cdc725fe40318';
GRANT ALL ON SCHEMA public to test_app;
