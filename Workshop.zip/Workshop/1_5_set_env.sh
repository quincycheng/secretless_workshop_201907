#!/bin/bash 

echo 'Execute "eval $(minikube docker-env)" to complete the setup'
