#!/bin/bash
minikube start
