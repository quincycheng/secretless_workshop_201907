#!/bin/bash

echo 'Execute "minikube tunnel" in another separated terminal for tunneling'
