#!/bin/bash
kubectl cluster-info

kubectl get nodes
