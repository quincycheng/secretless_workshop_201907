#!/bin/bash

minikube service list

echo "Is conjur-oss-ingress showing an url with port 32222?"
